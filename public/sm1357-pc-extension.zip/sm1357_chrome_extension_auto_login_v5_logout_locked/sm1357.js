(function () {
  function currentPath() {
    try {
      return new URL(window.location.href).pathname;
    } catch (e) {
      return '';
    }
  }

  function getUserFromUrl() {
    try {
      const url = new URL(window.location.href);
      const user = url.searchParams.get('user');
      return user ? user.trim() : '';
    } catch (e) {
      return '';
    }
  }

  function getUserFromPageText() {
    const text = document.body ? document.body.innerText : '';
    const match = text.match(/로그인\s*회원\s*:\s*([A-Za-z0-9_-]+)/);
    return match ? match[1].trim() : '';
  }

  function showBadge(text, color) {
    const old = document.getElementById('sm1357-login-saved-badge');
    if (old) old.remove();

    const badge = document.createElement('div');
    badge.id = 'sm1357-login-saved-badge';
    badge.textContent = text;

    const style = document.createElement('style');
    style.textContent = `
      #sm1357-login-saved-badge {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 2147483647;
        padding: 12px 14px;
        background: ${color || 'rgba(22, 163, 74, 0.96)'};
        color: #fff;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 800;
        font-family: Arial, sans-serif;
        box-shadow: 0 10px 25px rgba(0,0,0,0.35);
      }
    `;

    document.documentElement.appendChild(style);
    document.body.appendChild(badge);

    setTimeout(() => {
      badge.remove();
    }, 3500);
  }

  async function saveMemberId(memberId) {
    if (!memberId) return;
    await chrome.storage.local.set({ sm1357MemberId: memberId });
    showBadge(`SM1357 로그인 저장됨: ${memberId}`, 'rgba(22, 163, 74, 0.96)');
  }

  async function clearMemberId(reason) {
    await chrome.storage.local.remove(['sm1357MemberId']);
    if (reason) {
      showBadge(reason, 'rgba(220, 38, 38, 0.96)');
    }
  }

  async function init() {
    const path = currentPath();

    // 핵심: 로그인 페이지 또는 로그아웃 페이지로 오면 저장된 회원ID 삭제
    // 이렇게 해야 회원이 로그아웃된 상태에서는 배트맨에서 전송 불가
    if (path === '/login' || path === '/member-logout' || path === '/logout') {
      await clearMemberId('SM1357 로그아웃: 회원ID 삭제됨');
      return;
    }

    // 로그인 성공 후 회원페이지에서만 회원ID 저장
    // 주소 예: /betman?user=vip001
    if (path === '/betman') {
      const userFromUrl = getUserFromUrl();
      const userFromPage = getUserFromPageText();
      const memberId = userFromUrl || userFromPage;

      if (memberId) {
        await saveMemberId(memberId);
      }
    }
  }

  init();
})();