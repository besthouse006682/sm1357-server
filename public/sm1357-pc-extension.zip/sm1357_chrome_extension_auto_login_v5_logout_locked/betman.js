(function () {
  if (document.getElementById('sm1357-send-box')) return;

  const box = document.createElement('div');
  box.id = 'sm1357-send-box';
  box.innerHTML = `
    <div id="sm1357-title">SM1357</div>
    <div id="sm1357-member">회원 확인 중...</div>
    <button id="sm1357-send-button" type="button">구매내역 보내기</button>
    <div id="sm1357-status">회원ID는 sm1357.kr 로그인 상태에서만 유지됩니다.</div>
  `;

  const style = document.createElement('style');
  style.textContent = `
    #sm1357-send-box {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 2147483647;
      width: 215px;
      padding: 12px;
      background: rgba(15, 23, 42, 0.96);
      border: 1px solid rgba(148, 163, 184, 0.55);
      border-radius: 14px;
      box-shadow: 0 12px 30px rgba(0,0,0,0.35);
      font-family: Arial, sans-serif;
      color: #fff;
      box-sizing: border-box;
    }

    #sm1357-title {
      font-size: 13px;
      font-weight: 700;
      color: #93c5fd;
      margin-bottom: 6px;
      letter-spacing: 0.3px;
    }

    #sm1357-member {
      font-size: 13px;
      color: #e5e7eb;
      margin-bottom: 8px;
      font-weight: 700;
    }

    #sm1357-send-button {
      width: 100%;
      border: 0;
      border-radius: 10px;
      padding: 11px 10px;
      color: #fff;
      font-size: 14px;
      font-weight: 800;
      cursor: pointer;
      box-sizing: border-box;
      margin-top: 7px;
      background: #16a34a;
    }

    #sm1357-send-button:hover {
      background: #15803d;
    }

    #sm1357-send-button:disabled {
      background: #64748b;
      cursor: not-allowed;
    }

    #sm1357-status {
      margin-top: 8px;
      font-size: 12px;
      color: #cbd5e1;
      line-height: 1.4;
      word-break: keep-all;
    }
  `;

  document.documentElement.appendChild(style);
  document.body.appendChild(box);

  const memberEl = document.getElementById('sm1357-member');
  const button = document.getElementById('sm1357-send-button');
  const status = document.getElementById('sm1357-status');

  let currentMemberId = '';

  function refreshMemberLabel() {
    chrome.storage.local.get(['sm1357MemberId'], (saved) => {
      currentMemberId = saved.sm1357MemberId || '';

      if (currentMemberId) {
        memberEl.textContent = `회원: ${currentMemberId}`;
        status.textContent = '최종 구매내역 화면에서 버튼을 누르세요.';
        button.disabled = false;
      } else {
        memberEl.textContent = '회원ID 없음';
        status.textContent = 'sm1357.kr/login에서 로그인해야 전송됩니다.';
        button.disabled = false;
      }
    });
  }

  button.addEventListener('click', () => {
    refreshMemberLabel();

    setTimeout(() => {
      if (!currentMemberId) {
        alert('회원ID가 없습니다. sm1357.kr/login에서 먼저 로그인하세요.');
        return;
      }

      const ok = confirm(`현재 배트맨 화면을 캡처해서 ${currentMemberId} 구매내역으로 보낼까요?`);
      if (!ok) return;

      button.disabled = true;
      button.textContent = '전송 중...';
      status.textContent = '화면 캡처 후 전송 중입니다.';

      chrome.runtime.sendMessage({
        action: 'SM1357_CAPTURE_SEND'
      }, (response) => {
        button.disabled = false;
        button.textContent = '구매내역 보내기';

        if (chrome.runtime.lastError) {
          status.textContent = '오류: ' + chrome.runtime.lastError.message;
          alert('전송 오류: ' + chrome.runtime.lastError.message);
          return;
        }

        if (response && response.success) {
          currentMemberId = response.username || currentMemberId;
          memberEl.textContent = `회원: ${currentMemberId}`;
          status.textContent = `${currentMemberId} 전송 완료. 관리자 페이지에서 확인하세요.`;
          alert('구매내역 전송 완료');
        } else {
          const msg = response && response.message ? response.message : '전송 실패';
          status.textContent = '실패: ' + msg;
          alert('전송 실패: ' + msg);
          refreshMemberLabel();
        }
      });
    }, 100);
  });

  refreshMemberLabel();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sm1357MemberId) {
      refreshMemberLabel();
    }
  });
})();