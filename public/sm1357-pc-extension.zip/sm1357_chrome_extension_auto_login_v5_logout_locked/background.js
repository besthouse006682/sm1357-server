const SERVER_URL = 'https://sm1357.kr/api/send';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.action !== 'SM1357_CAPTURE_SEND') {
    return;
  }

  (async () => {
    try {
      const tab = sender.tab;

      if (!tab || !tab.windowId) {
        sendResponse({ success: false, message: '현재 탭 정보를 찾을 수 없습니다.' });
        return;
      }

      const saved = await chrome.storage.local.get(['sm1357MemberId']);
      const username = saved.sm1357MemberId || '';

      if (!username) {
        sendResponse({
          success: false,
          message: '회원ID가 없습니다. sm1357.kr/login에서 로그인 후 다시 시도하세요.'
        });
        return;
      }

      const imageDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png'
      });

      const response = await fetch(SERVER_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          type: 'IMAGE',
          memo: '배트맨 구매내역 화면 캡처',
          image: imageDataUrl
        })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        sendResponse({
          success: false,
          message: data.message || '서버 전송 실패'
        });
        return;
      }

      sendResponse({
        success: true,
        username,
        message: '구매내역 이미지 전송 완료'
      });
    } catch (err) {
      sendResponse({
        success: false,
        message: err && err.message ? err.message : '알 수 없는 오류'
      });
    }
  })();

  return true;
});